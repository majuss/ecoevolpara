#define JBB_VERSION "0.0.0.0"
